import React from 'react';
import { Box, Typography } from '@mui/material';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';

const Footer = () => {
  return (
    <>
      {/* Rodapé transparente com crédito */}
      

      {/* Botão flutuante do suporte */}
      <Box
        onClick={() => window.open('https://athix.tomticket.com', '_blank')}
        sx={{
          position: 'fixed',
          bottom: 24,
          right: 24,
          backgroundColor: '#F0B429',
          color: 'white',
          borderRadius: '50%',
          width: 56,
          height: 56,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          cursor: 'pointer',
          boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
          zIndex: 1300,
        }}
      >
        <SupportAgentIcon sx={{ fontSize: 30 }} />
      </Box>
    </>
  );
};

export default Footer;
